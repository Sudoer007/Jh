package com.example.epubstudio

import android.util.Base64
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Entities
import org.jsoup.parser.Parser
import java.io.InputStream
import java.io.OutputStream
import java.net.URLDecoder
import java.util.regex.Matcher
import java.util.regex.Pattern
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class SearchResult(val total: Int, val chapters: Int)

class EpubBook private constructor(private val entries: LinkedHashMap<String, ByteArray>) {

    var title: String = ""
        private set
    private var opfPath = ""
    private val spine = mutableListOf<String>()

    val chapterCount: Int get() = spine.size

    // ---------------------------------------------------------------- yükleme
    companion object {
        fun load(input: InputStream): EpubBook {
            val map = LinkedHashMap<String, ByteArray>()
            ZipInputStream(input).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    if (!e.isDirectory) map[e.name] = zin.readBytes()
                    e = zin.nextEntry
                }
            }
            val book = EpubBook(map)
            book.parse()
            return book
        }

        /** [base] dosyasına göre göreli [rel] yolu zip içi mutlak yola çevirir. */
        fun resolve(base: String, rel: String): String {
            val cleaned = rel.substringBefore('#').substringBefore('?')
            val decoded = try {
                URLDecoder.decode(cleaned.replace("+", "%2B"), "UTF-8")
            } catch (e: Exception) { cleaned }
            val parts = base.substringBeforeLast('/', "").split('/')
                .filter { it.isNotEmpty() }.toMutableList()
            for (seg in decoded.split('/')) {
                when (seg) {
                    "", "." -> {}
                    ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.size - 1)
                    else -> parts.add(seg)
                }
            }
            return parts.joinToString("/")
        }
    }

    private fun parse() {
        val container = entries["META-INF/container.xml"]
            ?: error("Geçerli bir EPUB değil (container.xml yok)")
        val cdoc = Jsoup.parse(String(container, Charsets.UTF_8), "", Parser.xmlParser())
        opfPath = cdoc.select("rootfile").first()?.attr("full-path")
            ?: error("OPF dosyası bulunamadı")
        val opf = Jsoup.parse(
            String(entries[opfPath] ?: error("OPF dosyası eksik"), Charsets.UTF_8),
            "", Parser.xmlParser()
        )
        title = opf.getElementsByTag("dc:title").first()?.text().orEmpty()

        val manifest = HashMap<String, String>()
        opf.select("manifest > item").forEach { manifest[it.attr("id")] = it.attr("href") }
        opf.select("spine > itemref").forEach { ref ->
            manifest[ref.attr("idref")]?.let { href ->
                val p = resolve(opfPath, href)
                if (entries.containsKey(p) && isHtml(p)) spine.add(p)
            }
        }
        if (spine.isEmpty()) spine.addAll(entries.keys.filter { isHtml(it) })
    }

    private fun isHtml(p: String): Boolean {
        val l = p.lowercase()
        return l.endsWith(".xhtml") || l.endsWith(".html") || l.endsWith(".htm")
    }

    // ------------------------------------------------- bul ve değiştir (Ctrl+H)
    private fun pattern(find: String, caseSensitive: Boolean, wholeWord: Boolean): Pattern {
        var p = Pattern.quote(find)
        if (wholeWord) p = "(?<![\\p{L}\\p{N}_])$p(?![\\p{L}\\p{N}_])"
        val flags = if (caseSensitive) 0 else Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
        return Pattern.compile(p, flags)
    }

    fun count(find: String, caseSensitive: Boolean, wholeWord: Boolean): SearchResult =
        run(find, null, caseSensitive, wholeWord)

    fun replaceAll(find: String, replacement: String, caseSensitive: Boolean, wholeWord: Boolean): SearchResult =
        run(find, replacement, caseSensitive, wholeWord)

    private fun run(find: String, replacement: String?, cs: Boolean, ww: Boolean): SearchResult {
        if (find.isEmpty()) return SearchResult(0, 0)
        val pat = pattern(find, cs, ww)
        var total = 0
        var chapters = 0
        for (path in entries.keys.toList().filter { isHtml(it) }) {
            val doc = Jsoup.parse(String(entries[path]!!, Charsets.UTF_8), "", Parser.xmlParser())
            var n = 0
            for (el in doc.allElements) {
                if (el.normalName() == "script" || el.normalName() == "style") continue
                for (tn in el.textNodes()) {
                    val src = tn.wholeText
                    val m: Matcher = pat.matcher(src)
                    var c = 0
                    while (m.find()) c++
                    if (c > 0) {
                        n += c
                        if (replacement != null) {
                            tn.text(pat.matcher(src).replaceAll(Matcher.quoteReplacement(replacement)))
                        }
                    }
                }
            }
            if (n > 0) {
                total += n; chapters++
                if (replacement != null) entries[path] = serialize(doc).toByteArray(Charsets.UTF_8)
            }
        }
        return SearchResult(total, chapters)
    }

    private fun serialize(doc: Document): String {
        doc.outputSettings()
            .prettyPrint(false)
            .syntax(Document.OutputSettings.Syntax.xml)
            .escapeMode(Entities.EscapeMode.xhtml)
            .charset(Charsets.UTF_8)
        return doc.outerHtml()
    }

    // ----------------------------------------------------------- EPUB kaydet
    fun write(out: OutputStream) {
        ZipOutputStream(out).use { z ->
            val mt = entries["mimetype"] ?: "application/epub+zip".toByteArray()
            val e = ZipEntry("mimetype").apply {
                method = ZipEntry.STORED
                size = mt.size.toLong()
                compressedSize = mt.size.toLong()
                crc = CRC32().also { it.update(mt) }.value
            }
            z.putNextEntry(e); z.write(mt); z.closeEntry()
            for ((name, bytes) in entries) {
                if (name == "mimetype") continue
                z.putNextEntry(ZipEntry(name)); z.write(bytes); z.closeEntry()
            }
        }
    }

    // ------------------------------------------------------------- PDF için
    /** Tüm bölümleri, görselleri ve stilleri tek bir HTML sayfasında birleştirir. */
    fun buildPrintableHtml(): String {
        val css = LinkedHashSet<String>()
        val body = StringBuilder()
        for (path in spine) {
            val doc = Jsoup.parse(String(entries[path] ?: continue, Charsets.UTF_8))
            doc.select("link[rel=stylesheet]").forEach { l ->
                entries[resolve(path, l.attr("href"))]?.let { css.add(String(it, Charsets.UTF_8)) }
            }
            doc.select("style").forEach { css.add(it.data()) }
            doc.select("img").forEach { img -> dataUri(path, img.attr("src"))?.let { img.attr("src", it) } }
            doc.select("image").forEach { im ->
                dataUri(path, im.attr("xlink:href"))?.let { im.attr("xlink:href", it) }
            }
            doc.select("script").remove()
            body.append("<section class=\"epub-chapter\">").append(doc.body().html()).append("</section>\n")
        }
        return """
            <!DOCTYPE html><html><head><meta charset="utf-8">
            <style>${css.joinToString("\n")}</style>
            <style>
              body{font-family:serif;line-height:1.5;font-size:12pt;margin:0;padding:0}
              img,svg{max-width:100%;height:auto}
              .epub-chapter{page-break-before:always}
              .epub-chapter:first-child{page-break-before:avoid}
            </style></head><body>$body</body></html>
        """.trimIndent()
    }

    private fun dataUri(base: String, src: String): String? {
        if (src.isBlank() || src.startsWith("data:") || src.startsWith("http")) return null
        val bytes = entries[resolve(base, src)] ?: return null
        val mime = when (src.substringAfterLast('.').lowercase()) {
            "png" -> "image/png"
            "gif" -> "image/gif"
            "svg" -> "image/svg+xml"
            "webp" -> "image/webp"
            else -> "image/jpeg"
        }
        return "data:$mime;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
    }
}
