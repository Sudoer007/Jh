package android.print

import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import java.io.File

/**
 * WebView'in print adapter'ını yazdırma penceresi açmadan doğrudan dosyaya PDF olarak yazar.
 * LayoutResultCallback / WriteResultCallback yapıcıları paket-özel olduğu için bu sınıf
 * android.print paketinde bulunmalıdır.
 */
class PdfPrinter(private val attributes: PrintAttributes) {

    fun print(adapter: PrintDocumentAdapter, output: File, onDone: (Boolean) -> Unit) {
        adapter.onLayout(null, attributes, CancellationSignal(),
            object : PrintDocumentAdapter.LayoutResultCallback() {
                override fun onLayoutFinished(info: PrintDocumentInfo?, changed: Boolean) {
                    try {
                        val pfd = ParcelFileDescriptor.open(
                            output,
                            ParcelFileDescriptor.MODE_READ_WRITE or
                                ParcelFileDescriptor.MODE_CREATE or
                                ParcelFileDescriptor.MODE_TRUNCATE
                        )
                        adapter.onWrite(arrayOf(PageRange.ALL_PAGES), pfd, CancellationSignal(),
                            object : PrintDocumentAdapter.WriteResultCallback() {
                                override fun onWriteFinished(pages: Array<out PageRange>?) {
                                    pfd.close(); onDone(true)
                                }
                                override fun onWriteFailed(error: CharSequence?) {
                                    pfd.close(); onDone(false)
                                }
                            })
                    } catch (e: Exception) {
                        onDone(false)
                    }
                }
                override fun onLayoutFailed(error: CharSequence?) = onDone(false)
            }, null)
    }
}
