package com.example.epubstudio

import android.app.Application
import android.content.Context
import android.net.Uri
import android.print.PdfPrinter
import android.print.PrintAttributes
import android.provider.OpenableColumns
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

class MainViewModel(app: Application) : AndroidViewModel(app) {

    var book by mutableStateOf<EpubBook?>(null); private set
    var fileName by mutableStateOf(""); private set
    var busy by mutableStateOf(false); private set
    var edited by mutableStateOf(false); private set
    var message by mutableStateOf<String?>(null)

    var find by mutableStateOf("")
    var replace by mutableStateOf("")
    var caseSensitive by mutableStateOf(false)
    var wholeWord by mutableStateOf(false)

    private var sourceUri: Uri? = null
    private val resolver get() = getApplication<Application>().contentResolver

    val baseName: String get() = fileName.substringBeforeLast('.').ifBlank { "kitap" }

    fun open(uri: Uri) {
        viewModelScope.launch {
            busy = true
            try {
                val b = withContext(Dispatchers.IO) {
                    resolver.openInputStream(uri)!!.use { EpubBook.load(it) }
                }
                book = b; sourceUri = uri; edited = false
                fileName = queryName(uri)
                message = "Dosya açıldı: ${b.chapterCount} bölüm"
            } catch (e: Exception) {
                message = "Dosya açılamadı: ${e.message}"
            } finally { busy = false }
        }
    }

    fun revert() { sourceUri?.let { open(it) } }

    fun count() {
        val b = book ?: return
        viewModelScope.launch {
            busy = true
            val r = withContext(Dispatchers.Default) { b.count(find, caseSensitive, wholeWord) }
            message = if (r.total == 0) "Eşleşme bulunamadı" else "${r.total} eşleşme bulundu (${r.chapters} bölümde)"
            busy = false
        }
    }

    fun replaceAll() {
        val b = book ?: return
        viewModelScope.launch {
            busy = true
            val r = withContext(Dispatchers.Default) { b.replaceAll(find, replace, caseSensitive, wholeWord) }
            if (r.total > 0) edited = true
            message = if (r.total == 0) "Eşleşme bulunamadı" else "${r.total} değişiklik yapıldı (${r.chapters} bölümde)"
            busy = false
        }
    }

    fun saveEpub(uri: Uri) {
        val b = book ?: return
        viewModelScope.launch {
            busy = true
            try {
                withContext(Dispatchers.IO) { resolver.openOutputStream(uri)!!.use { b.write(it) } }
                message = "EPUB kaydedildi"
            } catch (e: Exception) { message = "Kaydedilemedi: ${e.message}" }
            busy = false
        }
    }

    fun savePdf(uri: Uri, ctx: Context) {
        val b = book ?: return
        viewModelScope.launch {
            busy = true
            try {
                val html = withContext(Dispatchers.Default) { b.buildPrintableHtml() }
                val tmp = File(getApplication<Application>().cacheDir, "cikti.pdf")
                val ok = renderPdf(ctx, html, tmp)   // ana iş parçacığında çalışmalı
                if (ok) {
                    withContext(Dispatchers.IO) {
                        resolver.openOutputStream(uri)!!.use { o -> tmp.inputStream().use { it.copyTo(o) } }
                        tmp.delete()
                    }
                    message = "PDF kaydedildi"
                } else message = "PDF oluşturulamadı"
            } catch (e: Exception) { message = "PDF hatası: ${e.message}" }
            busy = false
        }
    }

    private suspend fun renderPdf(ctx: Context, html: String, out: File): Boolean =
        suspendCancellableCoroutine { cont ->
            val wv = WebView(ctx)
            var started = false
            wv.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String?) {
                    if (started) return
                    started = true
                    val attrs = PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                        .setResolution(PrintAttributes.Resolution("pdf", "pdf", 300, 300))
                        .setMinMargins(PrintAttributes.Margins(600, 600, 600, 600))
                        .build()
                    PdfPrinter(attrs).print(view.createPrintDocumentAdapter("kitap"), out) { ok ->
                        view.destroy()
                        if (cont.isActive) cont.resume(ok)
                    }
                }
            }
            wv.loadDataWithBaseURL("https://localhost/", html, "text/html", "UTF-8", null)
        }

    private fun queryName(uri: Uri): String =
        resolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) c.getString(i) else null
        } ?: "kitap.epub"
}
