package com.example.epubstudio

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null && intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { vm.open(it) }
        }
        setContent { EpubTheme { App(vm) } }
    }
}

@Composable
fun EpubTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: MainViewModel) {
    val ctx = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) {
        vm.message?.let { snackbar.showSnackbar(it); vm.message = null }
    }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) {
        it?.let(vm::open)
    }
    val epubSaver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/epub+zip")
    ) { it?.let(vm::saveEpub) }
    val pdfSaver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { it?.let { u -> vm.savePdf(u, ctx) } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("EPUB Stüdyo", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())

            // 1) Dosya seç
            SectionCard("1. Dosya") {
                Button(
                    onClick = { openLauncher.launch(arrayOf("application/epub+zip", "*/*")) },
                    enabled = !vm.busy,
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("📖  EPUB Seç") }
                vm.book?.let {
                    Text(
                        if (it.title.isNotBlank()) it.title else vm.fileName,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text("${vm.fileName} • ${it.chapterCount} bölüm",
                        style = MaterialTheme.typography.bodySmall)
                }
            }

            if (vm.book != null) {
                // 2) Bul ve değiştir
                SectionCard("2. Bul ve Değiştir (Ctrl+H)") {
                    OutlinedTextField(
                        value = vm.find, onValueChange = { vm.find = it },
                        label = { Text("Aranan kelime") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = vm.replace, onValueChange = { vm.replace = it },
                        label = { Text("Yeni kelime") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    SwitchRow("Büyük/küçük harf duyarlı", vm.caseSensitive) { vm.caseSensitive = it }
                    SwitchRow("Yalnızca tam kelime", vm.wholeWord) { vm.wholeWord = it }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(
                            onClick = vm::count,
                            enabled = !vm.busy && vm.find.isNotEmpty(),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) { Text("🔍 Say") }
                        Button(
                            onClick = vm::replaceAll,
                            enabled = !vm.busy && vm.find.isNotEmpty(),
                            modifier = Modifier.weight(1.4f).height(48.dp)
                        ) { Text("✅ Tümünü Değiştir") }
                    }
                    if (vm.edited) {
                        TextButton(onClick = vm::revert, enabled = !vm.busy) {
                            Text("↩ Değişiklikleri geri al (dosyayı yeniden aç)")
                        }
                    }
                }

                // 3) Kaydet / dönüştür
                SectionCard("3. Kaydet / Dönüştür") {
                    Button(
                        onClick = { epubSaver.launch(vm.baseName + "_duzenlendi.epub") },
                        enabled = !vm.busy,
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) { Text("💾  EPUB olarak kaydet") }
                    FilledTonalButton(
                        onClick = { pdfSaver.launch(vm.baseName + ".pdf") },
                        enabled = !vm.busy,
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) { Text("📄  PDF'e dönüştür") }
                    Text(
                        "PDF, kitabın güncel (düzenlenmiş) hâlinden oluşturulur. Büyük kitaplarda birkaç dakika sürebilir.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
